export CLASSPATH=.:lib/*:./*
java dk.dma.aisvirtualnet.AisVirtualNet $@

