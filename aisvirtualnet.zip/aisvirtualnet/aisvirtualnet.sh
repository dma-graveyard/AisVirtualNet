java -cp ".:./*:lib/*" dk.dma.aisvirtualnet.AisVirtualNet $@

